<?php
        
namespace App\Http\RepoInterfaces\mobile;   

interface ReservationInterface
{
                                      
    
                    
}