<?php
        
namespace App\Http\RepoClasses\mobile;

use App\Helpers\Helper;
use App\Http\RepoInterfaces\mobile\ReservationInterface;
use Exception;
use Illuminate\Database\Eloquent\Builder;

class ReservationRepo implements ReservationInterface
{
    // public $carCategory;
    
    public function __construct()
    {
        // $this->car = new Car();
        
    }
    
        
                    
}