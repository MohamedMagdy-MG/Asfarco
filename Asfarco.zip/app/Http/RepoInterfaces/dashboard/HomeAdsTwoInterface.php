<?php
        
namespace App\Http\RepoInterfaces\dashboard;   

interface HomeAdsTwoInterface
{
    public function ShowAds();
    public function UpdateAds($data = []);                                       
    
                    
}