<?php
        
namespace App\Http\RepoInterfaces\dashboard;   

interface HomeAdsOneInterface
{
    public function ShowAds();
    public function UpdateAds($data = []);                                       
    
                    
}