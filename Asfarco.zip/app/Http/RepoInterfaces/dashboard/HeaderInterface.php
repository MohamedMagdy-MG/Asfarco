<?php
        
namespace App\Http\RepoInterfaces\dashboard;   

interface HeaderInterface
{
    public function ShowHeader();
    public function UpdateHeader($data = []);                                       
    
                    
}