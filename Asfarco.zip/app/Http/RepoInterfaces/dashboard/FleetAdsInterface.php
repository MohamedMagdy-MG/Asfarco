<?php
        
namespace App\Http\RepoInterfaces\dashboard;   

interface FleetAdsInterface
{
    public function ShowAds();
    public function UpdateAds($data = []);                                       
    
                    
}