<?php
        
namespace App\Http\RepoInterfaces\dashboard;   

interface AboutAdsInterface
{
    public function ShowAds();
    public function UpdateAds($data = []);                                       
    
                    
}