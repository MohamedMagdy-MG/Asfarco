<?php
        
namespace App\Http\RepoInterfaces\frontend;   

interface HeaderInterface
{
    public function ShowHeader();
    
                    
}