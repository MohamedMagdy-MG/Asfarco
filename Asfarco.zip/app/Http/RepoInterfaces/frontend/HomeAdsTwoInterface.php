<?php
        
namespace App\Http\RepoInterfaces\frontend;   

interface HomeAdsTwoInterface
{
    public function ShowAds();
    
                    
}