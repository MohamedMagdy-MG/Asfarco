<?php
        
namespace App\Http\RepoInterfaces\frontend;   

interface HomeAdsOneInterface
{
    public function ShowAds();
    
                    
}