<?php
        
namespace App\Http\RepoInterfaces\frontend;   

interface FleetAdsInterface
{
    public function ShowAds();
    
                    
}