<?php
        
namespace App\Http\RepoInterfaces\frontend;   

interface AboutAdsInterface
{
    public function ShowAds();
    
                    
}